#!/bin/bash
set -e

# === 配置区域 ===
BOT_DIR="$HOME/telegram-bot"
SERVICE_NAME="telegram-bot"
PYTHON_VERSION="3.10"
# =================

echo "🚀 开始部署 Telegram 查重机器人..."

# 安装 Python 3.10
echo "📦 安装 Python $PYTHON_VERSION ..."
sudo apt update
sudo apt install -y software-properties-common
sudo add-apt-repository -y ppa:deadsnakes/ppa
sudo apt update
sudo apt install -y python${PYTHON_VERSION} python${PYTHON_VERSION}-venv python${PYTHON_VERSION}-dev

# 创建机器人目录
mkdir -p "$BOT_DIR"
cd "$BOT_DIR"

# 写入环境变量文件
cat > bot.env <<EOF
BOT_TOKEN=在这里填入你的真实Telegram机器人Token
EOF

# 创建虚拟环境
echo "🛠️ 创建 Python 虚拟环境 ..."
python${PYTHON_VERSION} -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install python-telegram-bot pandas python-dotenv

# 写入 bot.py 文件
cat > bot.py <<EOF
import os
import csv
from datetime import datetime
from telegram.ext import Updater, MessageHandler, Filters, CommandHandler
from dotenv import load_dotenv

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")
DATA_FILE = "phone_data.csv"

def is_valid_phone(phone):
    return phone.startswith('+') and phone[1:].isdigit() and 8 <= len(phone) <= 15

def load_phones():
    phones = {{}}
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                phones[row['phone']] = row
    return phones

def save_phone(phone, user_id, username):
    file_exists = os.path.exists(DATA_FILE)
    with open(DATA_FILE, 'a', newline='', encoding='utf-8') as f:
        fieldnames = ['phone', 'user_id', 'username', 'timestamp']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow({{
            'phone': phone,
            'user_id': user_id,
            'username': username,
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }})

def handle_message(update, context):
    message = update.message
    text = message.text.strip()
    user = message.from_user
    chat_id = message.chat.id

    if not is_valid_phone(text):
        return

    phones = load_phones()
    if text in phones:
        context.bot.send_message(
            chat_id=chat_id,
            reply_to_message_id=message.message_id,
            text=(
                "⚠️ 此手机号已提交过，请勿重复提交。\n"
                "⚠️ This phone number has already been submitted.\n"
                "⚠️ ဤဖုန်းနံပါတ်ကိုဖျော်ဖြေပြီးသားဖြစ်သည်။ ထပ်မံမတင်ပါနှင့်။"
            )
        )
    else:
        save_phone(text, user.id, user.username or "no_username")
        count = len(phones) + 1
        context.bot.send_message(
            chat_id=chat_id,
            reply_to_message_id=message.message_id,
            text=(
                f"✅ 感谢提交，{{user.first_name}}！你是第 {{count}} 位提交者。\n"
                f"✅ Thanks for your submission, {{user.first_name}}! You are the #{{count}} participant.\n"
                f"✅ တင်သွင်းပေးတဲ့အတွက် ကျေးဇူးတင်ပါတယ် {{user.first_name}}။ သင်သည် တက်ကြွသူ အမှတ် {{count}} ဖြစ်ပါသည်။"
            )
        )

def export_data(update, context):
    chat_id = update.effective_chat.id
    if not os.path.exists(DATA_FILE):
        update.message.reply_text("⚠️ 暂无数据可导出。")
        return
    context.bot.send_document(chat_id=chat_id, document=open(DATA_FILE, 'rb'), filename="phone_data.csv")

def main():
    updater = Updater(BOT_TOKEN, use_context=True)
    dispatcher = updater.dispatcher
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    dispatcher.add_handler(CommandHandler("导出", export_data))
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
EOF

# 写入 systemd 服务文件
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
sudo bash -c "cat > $SERVICE_FILE" <<EOL
[Unit]
Description=Telegram 查重机器人
After=network.target

[Service]
User=$USER
WorkingDirectory=$BOT_DIR
EnvironmentFile=$BOT_DIR/bot.env
ExecStart=$BOT_DIR/venv/bin/python $BOT_DIR/bot.py
Restart=always
RestartSec=5
StandardOutput=append:$BOT_DIR/bot.log
StandardError=append:$BOT_DIR/bot.log

[Install]
WantedBy=multi-user.target
EOL

# 启动服务
echo "🔁 启动机器人服务并设置为开机启动..."
sudo systemctl daemon-reload
sudo systemctl enable ${SERVICE_NAME}
sudo systemctl restart ${SERVICE_NAME}

echo "✅ 部署完成！请在 bot.env 文件中修改你的 Token 后重启服务。"
echo "👉 管理命令："
echo "  查看状态：sudo systemctl status ${SERVICE_NAME}"
echo "  重启服务：sudo systemctl restart ${SERVICE_NAME}"
echo "  查看日志：tail -f $BOT_DIR/bot.log"
