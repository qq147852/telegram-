#!/bin/bash
chmod +x deploy_telegram_bot.sh
echo "BOT_TOKEN=8184103812:AAEag95dBd9s5-LF8jvhApELXqY7tgqCFP0" > bot.env
./deploy_telegram_bot.sh
