#!/bin/bash

echo "🔍 开始检查 Telegram Bot 环境..."

# 1. 检查 bot.env 文件
if [ ! -f ~/telegram-bot/bot.env ]; then
  echo "❌ 未找到 ~/telegram-bot/bot.env 文件"
else
  echo "✅ 找到 bot.env 文件"
  TOKEN=$(grep BOT_TOKEN ~/telegram-bot/bot.env | cut -d= -f2)
  echo "🔐 当前 Token: $TOKEN"

  # 2. 检查 Token 是否有效
  echo "🌐 检查 Bot Token 是否有效..."
  curl -s https://api.telegram.org/bot$TOKEN/getMe | grep -q "ok"
  if [ $? -eq 0 ]; then
    echo "✅ Token 有效"
  else
    echo "❌ Token 无效，请检查 bot.env 中 BOT_TOKEN 的值"
  fi
fi

# 3. 检查 Python 虚拟环境
echo "🐍 检查 Python 虚拟环境..."
if [ -f ~/telegram-bot/venv/bin/python ]; then
  echo "✅ Python 虚拟环境已创建"
else
  echo "❌ 未找到虚拟环境，请检查是否执行过部署脚本"
fi

# 4. 检查依赖模块
echo "📦 检查 python-telegram-bot 是否安装..."
source ~/telegram-bot/venv/bin/activate
pip show python-telegram-bot &> /dev/null
if [ $? -eq 0 ]; then
  echo "✅ 模块已安装"
else
  echo "❌ 缺少模块，执行 pip install python-telegram-bot 安装"
fi

# 5. 检查 systemd 服务状态
echo "🧾 检查 systemd 服务状态..."
sudo systemctl is-active --quiet telegram-bot
if [ $? -eq 0 ]; then
  echo "✅ 服务正在运行"
else
  echo "❌ 服务未运行，查看日志：journalctl -u telegram-bot -n 50"
fi

echo "🧪 检查完成"
